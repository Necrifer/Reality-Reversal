# HEU-235 dedicated irradiation reactor

Designed against NuclearCraft Neoteric 1.20.1-1.2.35 and the current pack configuration. This is a calculated passive-safe design; formation, recipe processing and automated placement still require in-game verification.

Use **nuclearcraft:fuel_uranium_heu_235** (ordinary HEU-235 rods). The reactor must burn fuel to power irradiation and will still produce depleted rods. It is not a fuel-free machine, and its FE output is incidental.

## Build

Exterior 5x5x5; interior 3x3x3. Coordinates in layout.json run 0..4 including the shell. Build in a clear volume; all unspecified interior positions must be air.

Interior layers below are viewed from above, with the front at the top of each diagram. X runs left to right, Z top to bottom. E = passive Enderium heat sink, F = solid fuel cell, G = graphite block, I = ordinary irradiation chamber, dot = air.

```text
Bottom (Y=1)   Middle (Y=2)   Top (Y=3)
E . E          . . .          E . E
. . .          F G I          . . .
E . E          . . .          E . E
```

Use solid reactor casing for the whole shell except these four face-center blocks:

| Position | Block |
|---|---|
| (2,2,0), front | Fission Reactor Controller |
| (2,2,4), rear | Irradiator processor |
| (0,2,2), left | Fission Reactor Port |
| (4,2,2), right | Fission Reactor Port |

The Irradiator processor in the shell is distinct from the Irradiation Chamber inside. The template includes both. Rotate the controller/processor outward with the appropriate tool if necessary; the NBT leaves block-state facing at its default.

Materials: 94 reactor casings, 2 reactor ports, 1 controller, 1 Irradiator processor, 1 solid fuel cell, 1 graphite block, 1 ordinary irradiation chamber, 8 **passive** Enderium heat sinks. No active coolant is needed.

## Operation and thermal boundary

1. Form the reactor. Confirm 1 fuel cell, 1 active moderator, 1 valid irradiation chamber/line, and 8 valid heat sinks (960 H/t passive cooling).
2. Keep energy mode, with moderation at or below 100%. Configure fuel input and depleted-fuel removal through the reactor ports. Supply only ordinary HEU-235 rods.
3. Feed the desired irradiation ingredients and FE to the **Irradiator processor** and extract its products there. Configure its item/energy sides as needed. It must attach to the formed, fueled, operating reactor. Fuel ports handle reactor fuel, not the Irradiator's separate recipe inventory.
4. Apply the normal reactor enable/redstone control. Maintain output space for depleted fuel and an FE output route/load as needed so the reactor can keep operating. Check the Irradiator while a real recipe is running, not just while empty.

At full reactivity, 100% moderation and one operating Irradiator:

```text
HEU-235 base fuel heat                 300 H/t
One moderator attachment             +100 H/t
One irradiation line/processing call  +15 H/t
Calculated operating heat             415 H/t
Eight passive Enderium sinks          960 H/t
Net heat                             -545 H/t
```

Enderium sinks are at all eight interior corners. Each touches three perpendicular casing faces; no sink depends on another sink, fuel adjacency or coolant. The calculation takes no credit for environmental cooling and covers startup through 100% reactivity, with irradiation idle or active.

One line supplies flux 1 to the Irradiator. Its installed speed formula is `flux / 10 * fuel irradiation rate`; this conservative design prioritizes passive safety and low fuel-cell count, not maximum irradiation throughput. The controller's overcooling fuel-rate penalty is separate from that flux formula.

Do not treat this calculation as approval for arbitrary fuel substitutions, extra processors, added fuel cells/moderators, steam operation, external tick acceleration, changed heat-sink data, or moderation above 100%. Recalculate those changes. No recipe or fuel settings are changed by this datapack.

## Template and verification

The datapack supplies MultiBuilderTool gallery structure `mbtool:rr_irradiation/heu_235_passive_irradiator` (the UI may humanize the filename). Reload datapacks or restart after installation. Select this named template, not MultiBuilderTool's unrelated built-in Nuclearcraft Fission Reactor example. JSON layout.json is a coordinate/material reference, not a legacy reactor-planner import.

Generator checks corner cooling support, unique layout positions and the heat margin. Installed mod block IDs, moderator/casing tags and Enderium cooling must also be verified against the jar. Live gameplay validation remains pending; after building, use the controller counts listed above before accepting the structure as correct.
